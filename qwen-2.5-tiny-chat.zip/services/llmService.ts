import { CreateMLCEngine, MLCEngine, InitProgressCallback } from "@mlc-ai/web-llm";
import { DEFAULT_MODEL } from "../constants";

let engine: MLCEngine | null = null;

export const getEngine = (): MLCEngine | null => engine;

export const initializeEngine = async (
  onProgress: InitProgressCallback
): Promise<void> => {
  if (engine) return;

  try {
    // Create the engine with the specific Qwen model
    engine = await CreateMLCEngine(DEFAULT_MODEL.modelId, {
      initProgressCallback: onProgress,
      logLevel: "INFO", 
    });
  } catch (error) {
    console.error("Failed to initialize WebLLM engine:", error);
    throw error;
  }
};

export const generateResponse = async (
  messages: { role: string; content: string }[],
  onUpdate: (currentText: string) => void
): Promise<string> => {
  if (!engine) throw new Error("Engine not initialized");

  const completion = await engine.chat.completions.create({
    messages: messages as any,
    stream: true,
    temperature: 0.7,
    max_tokens: 1024, 
  });

  let fullText = "";
  for await (const chunk of completion) {
    const delta = chunk.choices[0]?.delta?.content || "";
    fullText += delta;
    onUpdate(fullText);
  }

  return fullText;
};

export const checkWebGPUSupport = async (): Promise<boolean> => {
  if (typeof navigator === 'undefined') return false;
  
  const nav = navigator as any;
  if (!nav.gpu) {
    console.warn("WebGPU: navigator.gpu is undefined");
    return false;
  }

  try {
    const adapter = await nav.gpu.requestAdapter();
    if (!adapter) {
      console.warn("WebGPU: requestAdapter returned null");
      return false;
    }
    return true;
  } catch (e) {
    console.error("WebGPU check failed:", e);
    return false;
  }
};