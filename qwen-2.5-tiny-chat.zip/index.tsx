import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { RefreshCw, AlertTriangle } from 'lucide-react';

// Error Boundary Component to catch rendering crashes
class ErrorBoundary extends React.Component<{children: React.ReactNode}, {hasError: boolean, error: any}> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("Uncaught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col items-center justify-center p-4 text-center font-sans" dir="rtl">
          <div className="bg-gray-800 border border-red-500/30 p-8 rounded-2xl shadow-2xl max-w-md w-full">
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center">
                <AlertTriangle size={32} className="text-red-500" />
              </div>
            </div>
            <h1 className="text-2xl font-bold text-red-400 mb-2">حدث خطأ غير متوقع</h1>
            <p className="text-gray-400 mb-6">توقف التطبيق عن العمل لتجنب انهيار المتصفح.</p>
            
            <div className="bg-black/50 p-4 rounded-lg mb-6 text-right border border-gray-700">
              <code className="text-xs text-red-300 font-mono break-all block max-h-32 overflow-y-auto" dir="ltr">
                {this.state.error?.toString() || "Unknown Error"}
              </code>
            </div>

            <button 
              onClick={() => window.location.reload()}
              className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-medium transition-all flex items-center justify-center gap-2"
            >
              <RefreshCw size={18} />
              إعادة تحميل الصفحة
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </React.StrictMode>
);