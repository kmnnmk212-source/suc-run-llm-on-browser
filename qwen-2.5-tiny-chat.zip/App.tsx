import React, { useState, useEffect, useRef } from 'react';
import { Send, Menu, Download, AlertTriangle, RefreshCw, CheckCircle2, XCircle, Terminal, Bug, FileCode, Zap } from 'lucide-react';
import { initializeEngine, generateResponse, checkWebGPUSupport } from './services/llmService';
import { ProgressBar } from './components/ProgressBar';
import { MessageBubble } from './components/MessageBubble';
import { Sidebar } from './components/Sidebar';
import { HelpModal } from './components/HelpModal';
import { Message, AppState, InitProgressReport } from './types';
import { SYSTEM_PROMPT, DEFAULT_MODEL } from './constants';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [progress, setProgress] = useState<InitProgressReport>({ progress: 0, text: '' });
  const [error, setError] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  
  // Diagnostic State
  const [diagnostics, setDiagnostics] = useState<{
    checked: boolean;
    isSecureContext: boolean;
    isCrossOriginIsolated: boolean;
    hasWebGPU: boolean;
    hasSharedArrayBuffer: boolean;
  }>({
    checked: false,
    isSecureContext: false,
    isCrossOriginIsolated: false,
    hasWebGPU: false,
    hasSharedArrayBuffer: false
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Check environment on mount
  useEffect(() => {
    const checkEnvironment = async () => {
      const isSecure = window.isSecureContext;
      const isIsolated = window.crossOriginIsolated;
      const hasSAB = typeof SharedArrayBuffer !== 'undefined';
      const hasGpu = await checkWebGPUSupport();

      setDiagnostics({
        checked: true,
        isSecureContext: isSecure,
        isCrossOriginIsolated: isIsolated,
        hasWebGPU: hasGpu,
        hasSharedArrayBuffer: hasSAB
      });

      if (!isSecure) {
        setAppState(AppState.ERROR);
        setError("الموقع غير آمن (Not Secure Context). يتطلب WebGPU اتصال HTTPS أو Localhost.");
      } else if (!isIsolated && !hasSAB) {
        // Warning only, some models might work without SAB or user might fix it later
        console.warn("SharedArrayBuffer is missing");
      } else if (!hasGpu) {
        setAppState(AppState.ERROR);
        setError("المتصفح أو الجهاز لا يدعم WebGPU. يرجى استخدام Chrome/Edge على جهاز حديث.");
      }
    };
    
    checkEnvironment();
  }, []);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, appState]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [inputText]);

  const handleLoadModel = async () => {
    setAppState(AppState.LOADING_MODEL);
    setError(null);
    try {
      await initializeEngine((report) => {
        setProgress({
          progress: report.progress,
          text: report.text
        });
      });
      setAppState(AppState.READY);
      // Add initial system greeting
      setMessages([{
        id: 'welcome',
        role: 'assistant',
        content: `أهلاً! أنا ${DEFAULT_MODEL.name}. أنا جاهز للمساعدة.`,
        timestamp: Date.now()
      }]);
    } catch (err: any) {
      console.error(err);
      setAppState(AppState.ERROR);
      const errMessage = err.message || (typeof err === 'string' ? err : JSON.stringify(err));
      setError(errMessage);
    }
  };

  const handleSend = async () => {
    if (!inputText.trim() || appState !== AppState.READY) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputText.trim(),
      timestamp: Date.now()
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInputText('');
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
    setAppState(AppState.GENERATING);

    try {
      // Prepare format for WebLLM
      const chatHistory = [
        { role: 'system', content: SYSTEM_PROMPT },
        ...newMessages.map(m => ({ role: m.role, content: m.content }))
      ];

      // Create a placeholder for the bot response
      const botMsgId = (Date.now() + 1).toString();
      setMessages(prev => [
        ...prev,
        { id: botMsgId, role: 'assistant', content: '', timestamp: Date.now() }
      ]);

      await generateResponse(chatHistory, (currentText) => {
        setMessages(prev => prev.map(msg => 
          msg.id === botMsgId ? { ...msg, content: currentText } : msg
        ));
      });

      setAppState(AppState.READY);
    } catch (err: any) {
      console.error(err);
      setError("حدث خطأ أثناء التوليد: " + err.message);
      setAppState(AppState.READY);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const resetChat = () => {
    setMessages([{
      id: 'welcome',
      role: 'assistant',
      content: 'تم مسح المحادثة. كيف يمكنني مساعدتك؟',
      timestamp: Date.now()
    }]);
  };

  const DiagnosticItem = ({ label, status }: { label: string, status: boolean }) => (
    <div className="flex items-center justify-between p-3 bg-gray-800 rounded-lg border border-gray-700">
      <span className="text-gray-300">{label}</span>
      {status ? (
        <div className="flex items-center text-green-400 gap-2">
          <span className="text-xs font-bold">نجح</span>
          <CheckCircle2 size={18} />
        </div>
      ) : (
        <div className="flex items-center text-red-400 gap-2">
          <span className="text-xs font-bold">فشل</span>
          <XCircle size={18} />
        </div>
      )}
    </div>
  );

  const isShaderError = error?.toLowerCase().includes('shader') || error?.toLowerCase().includes('compute stage');

  return (
    <div className="flex h-screen bg-gray-900 text-gray-100 overflow-hidden">
      <HelpModal isOpen={isHelpOpen} onClose={() => setIsHelpOpen(false)} />
      
      <Sidebar 
        isOpen={isSidebarOpen} 
        appState={appState} 
        onReset={resetChat}
        onShowHelp={() => setIsHelpOpen(true)}
      />

      {/* Overlay for mobile sidebar */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 md:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      <main className="flex-1 flex flex-col min-w-0 relative">
        {/* Top Bar */}
        <header className="h-16 flex items-center justify-between px-4 border-b border-gray-800 bg-gray-900/95 backdrop-blur z-20">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 hover:bg-gray-800 rounded-lg md:hidden transition-colors"
            >
              <Menu size={20} />
            </button>
            <div className="flex flex-col">
              <span className="font-bold text-lg bg-clip-text text-transparent bg-gradient-to-l from-blue-400 to-indigo-200">
                {DEFAULT_MODEL.name}
              </span>
            </div>
          </div>
          
          {/* Status Indicator */}
          <div className="flex items-center gap-2">
             {appState === AppState.READY && (
               <span className="flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-400/10 px-2 py-1 rounded-full border border-emerald-400/20">
                 <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                 متصل
               </span>
             )}
          </div>
        </header>

        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth">
          
          {appState === AppState.IDLE && (
            <div className="h-full flex flex-col items-center justify-center text-center p-8 animate-in fade-in zoom-in duration-500">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center mb-6 shadow-2xl shadow-blue-500/20">
                <Zap size={32} className="text-white" />
              </div>
              <h2 className="text-2xl font-bold mb-2">النموذج المستقر</h2>
              <h3 className="text-lg text-blue-300 mb-4 font-mono ltr">{DEFAULT_MODEL.name}</h3>
              <p className="text-gray-400 max-w-md mb-8 leading-relaxed">
                هذا النموذج (Llama 3.2 1B) هو الأكثر توافقاً واستقراراً.
                <br/>
                حجمه مناسب (~880MB) ويعمل بكفاءة عالية.
              </p>
              <button 
                onClick={handleLoadModel}
                className="px-8 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-full font-medium transition-all transform hover:scale-105 shadow-lg hover:shadow-blue-500/25 flex items-center gap-2"
              >
                <Download size={18} />
                تحميل النموذج
              </button>
            </div>
          )}

          {appState === AppState.LOADING_MODEL && (
             <div className="h-full flex items-center justify-center">
               <ProgressBar progress={progress.progress} text={progress.text} />
             </div>
          )}

          {appState === AppState.ERROR && (
             <div className="h-full flex items-center justify-center p-6 overflow-y-auto">
               <div className="bg-red-500/10 border border-red-500/20 p-6 rounded-2xl max-w-md w-full">
                 <div className="flex justify-center mb-4">
                    <AlertTriangle size={48} className="text-red-500" />
                 </div>
                 <h3 className="text-xl font-bold text-red-400 mb-2 text-center">فشل التشغيل</h3>
                 
                 {/* Error Detail Box */}
                 <div className="bg-black/40 rounded-lg p-3 mb-4 border border-red-500/30">
                    <div className="flex items-center gap-2 text-red-300 text-xs font-bold mb-1 uppercase tracking-wider">
                      <Bug size={12} />
                      تفاصيل الخطأ
                    </div>
                    <code className="text-xs text-gray-300 font-mono break-all block whitespace-pre-wrap max-h-32 overflow-y-auto" dir="ltr">
                      {error}
                    </code>
                 </div>
                 
                 {diagnostics.checked && (
                   <div className="space-y-2 mb-6 text-sm">
                     <DiagnosticItem label="اتصال آمن (HTTPS)" status={diagnostics.isSecureContext} />
                     <DiagnosticItem label="تهيئة الخادم (Headers)" status={diagnostics.isCrossOriginIsolated} />
                     <DiagnosticItem label="دعم الذاكرة (SharedArrayBuffer)" status={diagnostics.hasSharedArrayBuffer} />
                     <DiagnosticItem label="دعم كارت الشاشة (WebGPU)" status={diagnostics.hasWebGPU} />
                   </div>
                 )}

                 {!diagnostics.hasSharedArrayBuffer && (
                   <div className="bg-yellow-500/10 p-4 rounded-lg mb-4 text-xs text-yellow-200 border border-yellow-500/20">
                      <p className="font-bold mb-2 flex items-center gap-2">
                        <FileCode size={14} />
                         تنبيه: الذاكرة
                      </p>
                      <p>قد يعمل النموذج ببطء أو يفشل بسبب نقص SharedArrayBuffer. راجع دليل الإصلاح.</p>
                   </div>
                 )}

                 <div className="flex gap-2">
                   <button 
                    onClick={() => setIsHelpOpen(true)}
                    className="flex-1 px-4 py-3 bg-gray-700 hover:bg-gray-600 text-blue-300 rounded-lg text-sm transition-colors flex items-center justify-center gap-2"
                   >
                     <Terminal size={16} />
                     دليل الإصلاح
                   </button>
                   
                   <button 
                    onClick={() => window.location.reload()}
                    className="flex-1 px-4 py-3 bg-red-600 hover:bg-red-500 text-white rounded-lg text-sm transition-colors flex items-center justify-center gap-2"
                   >
                     <RefreshCw size={16} />
                     تحديث
                   </button>
                 </div>
               </div>
             </div>
          )}

          {(appState === AppState.READY || appState === AppState.GENERATING) && (
            <div className="max-w-3xl mx-auto w-full pt-4 pb-4">
              {messages.map((msg) => (
                <MessageBubble key={msg.id} message={msg} />
              ))}
              {appState === AppState.GENERATING && messages[messages.length - 1]?.role === 'user' && (
                <div className="flex justify-end mb-4">
                   <div className="bg-gray-800 rounded-2xl px-4 py-3 flex gap-1">
                     <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></div>
                     <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                     <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                   </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="p-4 bg-gray-900 border-t border-gray-800">
          <div className="max-w-3xl mx-auto relative">
            <textarea
              ref={textareaRef}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={appState === AppState.READY ? "اكتب رسالتك هنا..." : "يجب تحميل النموذج أولاً..."}
              disabled={appState !== AppState.READY}
              rows={1}
              className="w-full bg-gray-800 text-gray-100 rounded-2xl pl-4 pr-12 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50 border border-gray-700 resize-none disabled:opacity-50 disabled:cursor-not-allowed max-h-[120px]"
              dir="auto"
            />
            <button
              onClick={handleSend}
              disabled={!inputText.trim() || appState !== AppState.READY}
              className="absolute left-2 bottom-2 p-2 bg-blue-600 text-white rounded-xl hover:bg-blue-500 disabled:bg-gray-700 disabled:text-gray-500 transition-all shadow-lg disabled:shadow-none"
            >
              <Send size={18} />
            </button>
          </div>
          <p className="text-center text-[10px] text-gray-600 mt-2">
            يعمل النموذج بالكامل على جهازك ({DEFAULT_MODEL.name}).
          </p>
        </div>
      </main>
    </div>
  );
};

export default App;