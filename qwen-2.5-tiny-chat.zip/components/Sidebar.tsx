import React from 'react';
import { Info, Cpu, Trash2, Github, HelpCircle } from 'lucide-react';
import { DEFAULT_MODEL } from '../constants';
import { AppState } from '../types';

interface SidebarProps {
  isOpen: boolean;
  appState: AppState;
  onReset: () => void;
  onShowHelp: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, appState, onReset, onShowHelp }) => {
  const isReady = appState === AppState.READY || appState === AppState.GENERATING;

  return (
    <div className={`
      fixed inset-y-0 right-0 z-40 w-64 bg-gray-900 border-l border-gray-800 transform transition-transform duration-300 ease-in-out shadow-2xl
      ${isOpen ? 'translate-x-0' : 'translate-x-full'}
      md:relative md:translate-x-0 md:block
    `}>
      <div className="h-full flex flex-col p-4">
        {/* Header */}
        <div className="flex items-center gap-2 mb-8 text-primary-400">
          <Cpu size={24} />
          <h1 className="text-xl font-bold">Local Chat</h1>
        </div>

        {/* Model Info Card */}
        <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700 mb-6">
          <h2 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-2">
            <Info size={12} />
            معلومات النموذج
          </h2>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">الاسم:</span>
              <span className="text-gray-200 font-mono text-xs">{DEFAULT_MODEL.name}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">الحجم:</span>
              <span className="text-gray-200">{DEFAULT_MODEL.size}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">الحالة:</span>
              <span className={`font-medium ${isReady ? 'text-green-400' : 'text-yellow-400'}`}>
                {isReady ? 'جاهز' : 'غير محمل'}
              </span>
            </div>
          </div>
        </div>

        {/* Description */}
        <div className="mb-auto">
          <p className="text-sm text-gray-400 leading-relaxed">
            هذا الشات يعمل بالكامل داخل متصفحك باستخدام تقنية WebGPU. لا يتم إرسال أي بيانات إلى خوادم خارجية.
            <br/><br/>
            النموذج: {DEFAULT_MODEL.name}
          </p>
        </div>

        {/* Actions */}
        <div className="space-y-3 pt-4 border-t border-gray-800">
           <button 
            onClick={onReset}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg transition-colors text-sm"
          >
            <Trash2 size={16} />
            مسح المحادثة
          </button>
          
          <button 
            onClick={onShowHelp}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-blue-300 rounded-lg transition-colors text-sm"
          >
            <HelpCircle size={16} />
            طريقة التشغيل المحلي
          </button>

          <a 
            href="https://github.com/mlc-ai/web-llm" 
            target="_blank" 
            rel="noreferrer"
            className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-lg transition-colors text-sm"
          >
            <Github size={16} />
            WebLLM Source
          </a>
        </div>
      </div>
    </div>
  );
};