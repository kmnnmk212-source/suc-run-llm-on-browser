import React from 'react';
import { X, Terminal, Cpu, ShieldCheck, Copy, Check, FileCode } from 'lucide-react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const CopyButton = ({ text }: { text: string }) => {
    const [copied, setCopied] = React.useState(false);
    const handleCopy = () => {
      navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    };

    return (
      <button 
        onClick={handleCopy}
        className="absolute top-2 left-2 p-1.5 bg-gray-700 hover:bg-gray-600 rounded text-gray-300 transition-colors"
        title="نسخ الأمر"
      >
        {copied ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
      </button>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-gray-900 border border-gray-700 w-full max-w-3xl rounded-2xl shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-800">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Terminal className="text-blue-500" />
            دليل التشغيل المحلي (Local Setup)
          </h2>
          <button 
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-full transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto p-6 space-y-8">
          
          {/* Step 1: Prerequisites */}
          <section>
            <h3 className="text-lg font-semibold text-blue-300 mb-3">1. المتطلبات الأساسية</h3>
            <ul className="space-y-2 text-gray-300 text-sm">
              <li className="flex items-center gap-2">
                <ShieldCheck size={16} className="text-green-500" />
                متصفح حديث يدعم WebGPU (Google Chrome v113+ أو Edge).
              </li>
              <li className="flex items-center gap-2">
                <ShieldCheck size={16} className="text-green-500" />
                تثبيت بيئة <a href="https://nodejs.org/" target="_blank" className="text-blue-400 underline">Node.js</a>.
              </li>
            </ul>
          </section>

          {/* Step 2: Vite Config (CRITICAL FIX) */}
          <section>
             <div className="flex items-center gap-2 mb-3">
               <FileCode className="text-yellow-400" size={20} />
               <h3 className="text-lg font-semibold text-yellow-400">
                 2. حل مشكلة Headers / SharedArrayBuffer (مهم جداً)
               </h3>
             </div>
             <p className="text-sm text-gray-300 mb-3">
               لكي يعمل النموذج، يجب أن يسمح السيرفر المحلي بـ SharedArrayBuffer. قم بإنشاء ملف باسم 
               <code className="mx-1 text-blue-300 font-mono">vite.config.js</code> في المجلد الرئيسي للمشروع وضع فيه هذا الكود:
             </p>
             <div className="bg-gray-950 rounded-lg border border-gray-800 p-4 relative group">
                <code className="text-gray-300 font-mono text-xs block whitespace-pre leading-relaxed">
{`import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    headers: {
      'Cross-Origin-Embedder-Policy': 'require-corp',
      'Cross-Origin-Opener-Policy': 'same-origin',
    },
  },
})`}
                </code>
                <CopyButton text={`import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    headers: {
      'Cross-Origin-Embedder-Policy': 'require-corp',
      'Cross-Origin-Opener-Policy': 'same-origin',
    },
  },
})`} />
              </div>
          </section>

          {/* Step 3: Commands */}
          <section>
            <h3 className="text-lg font-semibold text-blue-300 mb-3">3. أوامر التشغيل</h3>
            <div className="space-y-4">
              <div className="bg-gray-950 rounded-lg border border-gray-800 p-4 relative group">
                <p className="text-gray-500 text-xs mb-2 font-mono">// 1. تثبيت المكتبات</p>
                <code className="text-green-400 font-mono text-sm">npm install</code>
                <CopyButton text="npm install" />
              </div>
              
              <div className="bg-gray-950 rounded-lg border border-gray-800 p-4 relative group">
                <p className="text-gray-500 text-xs mb-2 font-mono">// 2. تشغيل السيرفر</p>
                <code className="text-green-400 font-mono text-sm">npm run dev</code>
                <CopyButton text="npm run dev" />
              </div>
            </div>
          </section>

          {/* Step 4: Troubleshooting */}
          <section className="bg-gray-800/50 p-4 rounded-xl border border-gray-700">
             <h3 className="text-base font-semibold text-orange-400 mb-2 flex items-center gap-2">
               <Cpu size={18} />
               حل مشاكل Linux / Ubuntu (Shader Error)
             </h3>
             <p className="text-sm text-gray-300 mb-3 leading-relaxed">
               إذا ظهر خطأ <b>Invalid ShaderModule</b>:
             </p>
             <ol className="list-decimal list-inside text-sm text-gray-400 space-y-2 marker:text-gray-600">
               <li>تأكد أنك تستخدم تعريفات Vulkan الحديثة:
                 <code className="bg-black/50 px-2 py-0.5 rounded mx-1 text-gray-200">sudo apt install mesa-vulkan-drivers</code>
               </li>
               <li>شغل Chrome بهذا الأمر:
                 <div className="mt-2 bg-black/50 p-2 rounded border border-gray-700 overflow-x-auto">
                    <code className="text-xs font-mono text-gray-300 whitespace-nowrap">
                      google-chrome --enable-features=Vulkan
                    </code>
                 </div>
               </li>
             </ol>
          </section>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-800 bg-gray-900/50 rounded-b-2xl flex justify-end">
          <button 
            onClick={onClose}
            className="px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};