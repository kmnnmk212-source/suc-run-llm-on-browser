import React from 'react';

interface ProgressBarProps {
  progress: number;
  text: string;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ progress, text }) => {
  return (
    <div className="w-full max-w-md mx-auto p-4 bg-gray-800/50 rounded-xl border border-gray-700 backdrop-blur-sm shadow-xl">
      <div className="flex justify-between items-center mb-2">
        <span className="text-sm font-medium text-blue-300 animate-pulse">جاري تحميل النموذج...</span>
        <span className="text-xs text-gray-400 font-mono">{Math.round(progress * 100)}%</span>
      </div>
      <div className="w-full bg-gray-700 rounded-full h-2.5 overflow-hidden">
        <div 
          className="bg-gradient-to-r from-blue-500 to-indigo-500 h-2.5 rounded-full transition-all duration-300 ease-out" 
          style={{ width: `${progress * 100}%` }}
        ></div>
      </div>
      <p className="mt-3 text-xs text-center text-gray-400 truncate" dir="ltr">
        {text}
      </p>
    </div>
  );
};