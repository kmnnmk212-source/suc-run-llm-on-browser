import { ModelConfig } from './types';

// استخدام نموذج Llama 3.2 1B نسخة q4f32_1
// هذه النسخة هي الأكثر استقراراً وتوافقاً مع جميع كروت الشاشة
// وتحل مشاكل الـ Shader والانهيارات المفاجئة
export const DEFAULT_MODEL: ModelConfig = {
  modelId: 'Llama-3.2-1B-Instruct-q4f32_1-MLC',
  name: 'Llama 3.2 (1B)',
  size: '~880MB'
};

export const SYSTEM_PROMPT = "أنت مساعد ذكي ومفيد. أجب دائماً باللغة العربية بوضوح واختصار.";